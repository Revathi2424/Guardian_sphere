# Guardian_sphere
The webpage is a **safety-focused platform** designed to quickly send an emergency email with a single click. It features a simple interface with a prominent **"Emergency" button**, which, when clicked, automatically sends a pre-configured email to designated contacts. This email contains critical information, such as the user's current location. The page ensures ease of access and rapid communication during emergencies. It also provides additional features to empower society by helping joining organizations and clubs to building on. 

# Screenshots

![WhatsApp Image 2024-12-06 at 5 22 52 PM](https://github.com/user-attachments/assets/4f51cc69-5600-4736-8d7b-5f122507e2ba)
![WhatsApp Image 2024-12-06 at 5 22 51 PM (2)](https://github.com/user-attachments/assets/c08e7cf4-ef39-4ff5-a76e-1e662c3e29b1)
![WhatsApp Image 2024-12-06 at 5 22 51 PM (1)](https://github.com/user-attachments/assets/3283e18f-e998-4fdf-bbdf-def2f4bbe160)
![WhatsApp Image 2024-12-06 at 5 22 51 PM](https://github.com/user-attachments/assets/4fd9b184-7b10-4876-bae6-0ef28443ade1)

# Report
[REPORT1 (2).docx](https://github.com/user-attachments/files/18040350/REPORT1.2.docx)
